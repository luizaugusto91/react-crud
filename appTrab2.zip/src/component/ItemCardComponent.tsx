// components/ItemCardComponent.tsx
import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useClientContext } from '../context/ClientContext';
import { ClientScreenNavigationProp } from '../router/navigation';
import { Button } from 'react-native-elements';

interface ItemCardProps {
    nome: string;
    id: number; // Usando number para representar long
}

const ItemCard: React.FC<ItemCardProps> = ({ nome, id }) => {
    return (
        <View style={styles.card}>
            <View style={styles.header}>
                <Text style={styles.cardTitle}>Nome: </Text>
                <Text style={styles.cardInfo}>{nome}</Text>
            </View>
            <View style={styles.footer}>
                <Pressable style={styles.buttonActionDetail}>
                    <Text>Detalhes</Text>
                </Pressable>
                <Pressable style={styles.buttonActionRemove}>
                    <Text>Remover</Text>
                </Pressable>
            </View>
            <View style={styles.footer}>
                <Button style={styles.buttonActionDetail} title="Detalhes"/>
                <Button style={styles.buttonActionRemove} title="Remover"/>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    card: {
        borderWidth: 1,
        borderColor: 'lightgray',
        margin: 5,
        borderRadius: 5,
        padding: 10, // Adicionado padding para melhor visualização do conteúdo
    },
    header: {   
        flex: 1,
        flexDirection: 'row',
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 10,
        flex: 1,
    },
    // Text
    cardTitle: {
        fontSize: 20,
        fontWeight: 'bold'
    },
    cardInfo: {
        fontSize: 20,
        fontWeight: 'normal'
    },
    buttonActionDetail: {
        margin: 5,
        fontSize: 12,
        backgroundColor: "blue",
        flex: 2,
        justifyContent: 'center',
        alignContent: 'center',
        flexDirection: 'column',
    },
    buttonActionRemove: {
        margin: 5,
        fontSize: 12,
        color: "red",
        flex: 2,
        alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
    },
});

export default ItemCard;
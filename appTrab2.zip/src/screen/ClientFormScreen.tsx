// components/ClientFormScreen.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useClientContext } from '../context/ClientContext';

const ClientFormScreen = () => {
    const { selectedClientId } = useClientContext();

    return (
        <View style={styles.container}>
            <Text style={styles.text}>Detalhes do Cliente</Text>
            <Text style={styles.text}>ID: {selectedClientId}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        fontSize: 20,
    }
});

export default ClientFormScreen;
import { StatusBar } from "expo-status-bar";
import { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable } from "react-native";
import { Button } from 'react-native-elements';
import ItemCard from '../component/ItemCardComponent';

export default function ClientScreen({navigation}:any) {
    const [clients, setClients] = useState([]);

    return (
        <View style={{
            flexDirection: 'column',
            flex: 1,
            alignItems: 'stretch',
            justifyContent: 'flex-start'
        }}>
            <View style={styles.pageHeader}>
                <View style={styles.blank}></View>
                <View style={styles.pageField}>
                    <Text style={styles.pageTitle}> Lista de Clientes </Text>
                </View>
                <View style={styles.blank}>
                    <Button title="+" style={styles.addButton} titleStyle={styles.addButtonText}></Button>
                </View>
            </View>
            <ScrollView style={styles.scrollView}>
                <ItemCard id={0} nome={"Luiz Augusto da Silva"} />
            </ScrollView>
            <StatusBar style="auto"/>
        </View>
    )
}

const styles = StyleSheet.create({
    pageHeader:{
        // flex: 1,
        flexDirection: "row",
        marginTop: 40
    },
    // Black
    blank: {
        flex: 1
    },
    pageField:{
        flex: 3, 
        flexDirection: 'row', 
        alignContent: "center", 
        justifyContent: "center"
    },
    pageTitle:{
        fontSize: 24,
        fontWeight: "bold",
        color: "#42aadc",
        margin: 5,
        alignContent: "center",
        justifyContent: "center"
    },
    // Itens
    scrollView: {
        flex: 1,
        flexDirection: "column",
    },
    card: {
        flex: 1,
        backgroundColor: '#fff000',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 5,
        padding: 5
    },
    headerCard:{
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: 22,
    },
    bodyCard: {

    },
    footerCard:{
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    h3: {
        fontSize: 24,
    },
    buttonActionDetail: {
        margin: 5,
        fontSize: 12,
        color: "blue"
    },
    buttonActionRemove: {
        margin: 5,
        fontSize: 12,
        color: "red"
    },
    //
    addButton: {
        width: 40,
        height: 40,
        borderRadius: 30, // Torna o botão circular
        backgroundColor: 'blue', // Cor interna azul
        justifyContent: 'center', // Centraliza o conteúdo verticalmente
        alignItems: 'center', // Centraliza o conteúdo horizontalmente
        shadowColor: '#000', // Cor da sombra
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.25, // Opacidade da sombra
        shadowRadius: 3.84, // Raio da sombra
        elevation: 5, // Elevação (necessário para sombra no Android)
        borderWidth: 4, // Largura da borda branca
        borderColor: 'white', // Cor da borda branca
        margin: 5
    },
    addButtonText: {
        color: 'white',
        fontSize: 24,
        fontWeight: 'bold',
    }
});
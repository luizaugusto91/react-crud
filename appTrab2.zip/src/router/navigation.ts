import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

export type RootStackParamList = {
    ClientScreen: undefined;
    ClientFormScreen: undefined;
};

export type ClientScreenNavigationProp = StackNavigationProp<
    RootStackParamList,
    'ClientScreen'
>;

export type ClientFormScreenRouteProp = RouteProp<
    RootStackParamList,
    'ClientFormScreen'
>;

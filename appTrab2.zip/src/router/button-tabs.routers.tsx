import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// Icons
import { AntDesign, MaterialCommunityIcons } from '@expo/vector-icons';

import React from "react";
import HomeScreen from "../screen/HomeScreen";
import PropertyScreen from "../screen/PropertyScreen";
import ClientScreen from "../screen/ClientScreen";
import AboutScreen from "../screen/AboutScreen";

const {Navigator, Screen} = createBottomTabNavigator();

export function ButtonTabsRoutes() {
    return (
        <Navigator>
            <Screen 
                name="home" 
                component={HomeScreen} 
                options={{
                    title: "Home",
                    headerShown: false,
                    tabBarIcon: ({color, size}) => (
                        <AntDesign name="dashboard" size={size} color={color} />
                    )
                }}
            ></Screen>
            <Screen 
                name="property" 
                component={PropertyScreen} 
                options={{
                    title: "Imóveis",
                    headerShown: false,
                    headerStyle: { 
                        backgroundColor: '#1273de'
                    },
                    tabBarIcon: ({color, size}) => (
                        <AntDesign name="home" size={size} color={color} />
                    )
                }}
            ></Screen>
            <Screen 
                name="client" 
                component={ClientScreen} 
                options={{
                    title: "Clientes",
                    headerShown: false,
                    headerStyle: { 
                        backgroundColor: '#1273de'
                    },
                    tabBarIcon: ({color, size}) => (
                        <AntDesign name="user" size={size} color={color} />
                    )
                }}
            ></Screen>
            <Screen 
                name="about" 
                component={AboutScreen} 
                options={{
                    title: "Sobre",
                    headerShown: false,
                    headerStyle: { 
                        backgroundColor: '#1273de'
                    },
                    tabBarIcon: ({color, size}) => (
                        <AntDesign name="info" size={size} color={color} />
                    )
                }}
            ></Screen>
        </Navigator>
    )
}